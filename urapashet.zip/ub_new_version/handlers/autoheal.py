from pyrogram import Client, filters, enums
from pyrogram.types import Message

from loader import app
from functions import func
from storage.storage import Settings
from config import Zapominalka, black_iris, Me, GlobalStack

import asyncio, random, re

async def autoheal(app: Client, msg: Message):

    msgt = msg.text
    msgtl = msg.text.lower()
    yes = False
    yes_ = False
    id = None
    
    if Settings.autoheal is False:
        msg.stop_propagation()
    
    # Служба безопсности
    if msg.entities and '🕵️‍♂️ Служба безопасности' in msgt and re.findall(r'подвер[гла] заражению (неизвестным патогеном|патогеном)', msgt) and len(msg.entities) > 2 and msg.entities[0].type == enums.MessageEntityType.TEXT_MENTION:
        if msg.entities[0].user:
            id = msg.entities[0].user.id
            if id == Me.me.id:
                yes = True
    # «Кто-то» не задететила СБ
    elif msg.entities and '🦠 Кто-то подверг заражению' in msgt and msg.entities[0].type == enums.MessageEntityType.TEXT_MENTION:
        if msg.entities[0].user:
            id = msg.entities[0].user.id
            if Me.me.id == id:
                yes = True
    # Подвергли меня заражению в чате
    elif msg.entities and '🕵️‍♂️ Служба безопасности' not in msgt and re.findall(r'подвер[гла] заражению (неизвестным патогеном|патогеном)', msgt) and len(msg.entities) >= 2 and msg.entities[1].type == enums.MessageEntityType.TEXT_MENTION:
        if msg.entities[1].user:
            id = msg.entities[1].user.id
            if Me.me.id == id:
                yes_ = True
    # Сообщение в ирисе об горячке reply
    elif msg.entities and '🤒 У вас горячка, вызванная' in msgt and msg.reply_to_message:
        msgr = msg.reply_to_message
        if msgr.from_user.id == Me.me.id:
            await asyncio.sleep(2.5)
            yes_ = True
    # Сообщение ириса об горячке сразу после моего сообщения «заразить»
    if msg.from_user.id == Me.me.id and 'заразить' in msgtl:
        Zapominalka.heal_previous_msg = True
    if '🤒 У вас горячка, вызванная' in msgt and Zapominalka.heal_previous_msg:
        yes = True
    else:
        Zapominalka.heal_previous_msg = False
    
    if yes or yes_:
        if Settings.autoheal_full is False and Settings.autoheal_parted == 0 and Settings.autoheal_random is False:
            return
        if Settings.autoheal_parted != 0:
            if not (Settings.autoheal_num/Settings.autoheal_parted).is_integer():
                return
            if Settings.autoheal_num >= int(Settings.autoheal_num):
                Settings.autoheal_num = 1
            Settings.autoheal_num += 1
        if Settings.autoheal_random:
            if random.choice([True, False]) is False:
                return
        if Zapominalka.heal_pause:
            return
        GlobalStack.stop = True
        Zapominalka.heal_pause = True
        if yes:
            # await asyncio.sleep(random.randint(2, 6))
            await app.send_message(msg.chat.id, '!купить вакцину')
            # await func.heal_me(app, msg, iris_id = black_iris)
        elif yes_:
            # await asyncio.sleep(random.randint(2, 6))
            await app.send_message(msg.chat.id, '!купить вакцину')
            # await func.heal_me(app, msg, iris = True, iris_id = black_iris)
        GlobalStack.stop = False
        Zapominalka.heal_pause = False